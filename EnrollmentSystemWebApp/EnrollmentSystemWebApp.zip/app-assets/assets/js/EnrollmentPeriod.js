﻿$(document).ready(function () {

    LoadPage();

    $("#btnSave").click(function () {

        SendEnrollmentPeriod();

    });



});
function LoadPage() {

}

function SendEnrollmentPeriod() {

    $.ajax({
        url: urlSendEnrollmentPeriod,
        dataType: 'json',
        beforeSend: function () {
            //start = (new Date()).getTime();
            //$.blockUI({ message: '<div class="icon-spinner9 icon-spin icon-lg"></div>', timeout: 60000, overlayCSS: { backgroundColor: "#000000", opacity: .8, cursor: "wait" }, css: { border: 0, padding: 0, backgroundColor: "transparent" } });
        },
        complete: function () {
            //end = (new Date()).getTime();
            //var total = end - start;
            //$.unblockUI();
        },
        data: BuildRequestPeriod(),
        type: 'POST',
        async: true,
        success: function (data) {
            console.log(data);

            if (data.code === 0) {
                swal({
                    title: "Success!",
                    text: data.message,
                    type: "success",
                    confirmButtonText: "OK"
                });
            }

            // Loop the array of objects

        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            swal({
                title: "Error!",
                text: textStatus,
                type: "error",
                confirmButtonText: "OK"
            });
        }
    });
}

function BuildRequestPeriod() {
    var request = new Object();

    var fecini = null;
    var fecfin = null;
    var MemberId = null;


    fecini = $("#DateFromPeriod").val();
    fecfin = $("#DateToPeriod").val();
    //MemberId = ApplicationMemberID;

    request.fecini = fecini;
    request.fecfin = fecfin;
    request.MemberId = MemberId;
    return request;
}


