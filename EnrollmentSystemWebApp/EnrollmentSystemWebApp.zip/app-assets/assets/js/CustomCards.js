﻿$(document).ready(function () {

    $('.ch-item').mouseenter(function () {
        $('p').animate({ opacity: "1" });
    });

});